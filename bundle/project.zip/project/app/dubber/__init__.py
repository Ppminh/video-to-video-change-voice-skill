"""Douyin -> Vietnamese dubbing pipeline (chạy trên Mac M1, miễn phí)."""
__version__ = "0.1.0"
