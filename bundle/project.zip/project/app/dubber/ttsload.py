"""Nạp model giọng đọc VieNeu an toàn trên Mac.

Vấn đề: HuggingFace lưu model dạng 'liên kết' (symlink) trỏ tới các file nằm ở thư mục khác.
Bản onnxruntime mới coi file dữ liệu ngoài thư mục model là không an toàn và từ chối nạp.
Cách sửa: chuyển file thật vào đúng chỗ của liên kết (không tốn thêm ổ cứng), sau đó chạy
chế độ offline để lần sau không cần hỏi lại máy chủ HuggingFace.
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path

REPOS = ["pnnbao-ump/VieNeu-TTS-v3-Turbo", "OpenMOSS-Team/MOSS-Audio-Tokenizer-Nano-ONNX",
         "pnnbao-ump/VieNeu-TTS-v3-Nano"]


def _cache_dir() -> Path:
    try:
        from huggingface_hub import constants
        return Path(constants.HF_HUB_CACHE)
    except Exception:
        return Path.home() / ".cache" / "huggingface" / "hub"


def materialize() -> int:
    """Thay symlink trong snapshot bằng file thật. Trả về số file đã chuyển."""
    n = 0
    cache = _cache_dir()
    for repo in REPOS:
        snaps = cache / ("models--" + repo.replace("/", "--")) / "snapshots"
        if not snaps.exists():
            continue
        for p in snaps.rglob("*"):
            if p.is_symlink():
                target = p.resolve()
                if target.exists() and target.is_file():
                    p.unlink()
                    shutil.move(str(target), str(p))
                    n += 1
    return n


def cached(mode: str) -> bool:
    repo = REPOS[2] if mode == "nano" else REPOS[0]
    snaps = _cache_dir() / ("models--" + repo.replace("/", "--")) / "snapshots"
    return snaps.exists() and any(snaps.rglob("*.onnx"))


def _make(m: str, threads: int, precision: str):
    from vieneu import Vieneu
    kw = {"mode": m, "threads": threads}
    if m == "v3turbo" and precision and precision != "fp32":
        kw["precision"] = precision      # int8: nhanh hơn ~1,5 lần, cần nghe thử chất lượng
    return Vieneu(**kw)


def load(mode: str = "turbo", threads: int = 4, precision: str = "fp32"):
    m = "v3nano" if mode == "nano" else "v3turbo"
    if cached(mode):
        materialize()
        os.environ["HF_HUB_OFFLINE"] = "1"
        try:
            return _make(m, threads, precision)
        except Exception:
            os.environ.pop("HF_HUB_OFFLINE", None)
    try:
        return _make(m, threads, precision)
    except Exception as e:
        if "External data path" not in str(e) and "escapes model directory" not in str(e):
            raise
    # lần đầu: model vừa tải xong nhưng còn là symlink -> chuyển thành file thật rồi nạp lại
    materialize()
    return _make(m, threads, precision)
