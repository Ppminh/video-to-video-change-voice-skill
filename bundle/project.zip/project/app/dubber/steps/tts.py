"""B6 + B7. Chọn giọng cho từng nhân vật, đọc giọng Việt, khớp thời gian.

Chọn giọng (phân vai):
- 8 giọng miền Nam gốc x 5 "biến thể" (bình thường / trẻ / trầm / già / bé) = hơn 30 giọng khác nhau.
  Biến thể được tạo bằng kỹ thuật PSOLA của Praat ("Change gender"): đổi cao độ giọng (nốt nhạc)
  và độ dày giọng (formant) mà KHÔNG đổi tốc độ nói -> nghe như một người khác.
- AI dịch cho biết mỗi nhân vật: nam/nữ, tuổi (trẻ con/trẻ/trung niên/già). Người nói nhiều nhất
  được chọn giọng đầu tiên; nữ chính mặc định giọng "Thục Đoan" (đổi trong settings).
- Ưu tiên mỗi nhân vật một giọng gốc khác nhau; hết giọng gốc mới dùng biến thể.
Khớp thời gian từng câu ('ô thời gian' = từ lúc câu gốc bắt đầu tới câu kế tiếp, được mượn
thêm tối đa 1,5 giây im lặng):
  - Trước khi đọc: câu nào chắc chắn quá dài (ước lượng theo tốc độ đọc đã đo) -> nhờ AI rút gọn
    luôn, đỡ phải đọc 2 lần.
  - vừa ô -> đặt vào; dài hơn tới 1,2 lần -> tăng tốc giữ nguyên cao độ (ffmpeg atempo)
  - dài hơn nữa -> nhờ AI viết câu gọn hơn rồi đọc lại; vẫn dài thì tăng tốc tối đa 1,45 lần
"""
from __future__ import annotations

import time
from collections import Counter

import numpy as np

from .. import paths
from ..textnorm import normalize_vi
from ..utils import Job, ffmpeg, log, read_json, save_audio, threads, vi_syllables, write_json

RATES_FILE = paths.APPHOME / "voice_rates.json"

# biến thể: (nửa cung đổi cao độ, tỉ lệ formant). +12 nửa cung = cao gấp đôi.
VARIANTS = {
    "": (0.0, 1.0),
    "trẻ": (2.0, 1.04),
    "trầm": (-2.0, 0.97),
    "già": (-3.0, 0.94),
    "bé": (4.0, 1.12),
}
AGE_PREF = {
    "child": ["bé"],
    "young": ["", "trẻ", "trầm"],
    "adult": ["", "trầm", "trẻ"],
    "old": ["già", "trầm", ""],
}


def trim_silence(a: np.ndarray, sr: int) -> np.ndarray:
    if len(a) == 0:
        return a
    hop = int(sr * 0.01)
    n = len(a) // hop
    if n < 3:
        return a
    e = np.sqrt((a[:n * hop].reshape(n, hop) ** 2).mean(axis=1))
    thr = max(1e-4, 0.03 * float(e.max()))
    idx = np.where(e > thr)[0]
    if len(idx) == 0:
        return a
    s = max(0, (idx[0] - 4) * hop)
    t = min(len(a), (idx[-1] + 6) * hop)
    return a[s:t]


def apply_variant(a: np.ndarray, sr: int, variant: str) -> np.ndarray:
    """Đổi cao độ + formant bằng Praat PSOLA, giữ nguyên thời lượng."""
    st, fr = VARIANTS.get(variant or "", (0.0, 1.0))
    if (st == 0 and fr == 1.0) or len(a) < sr * 0.2:
        return a
    try:
        import parselmouth
        from parselmouth.praat import call
        snd = parselmouth.Sound(a.astype(np.float64), sampling_frequency=sr)
        f0 = call(snd.to_pitch(time_step=0.01, pitch_floor=60, pitch_ceiling=600), "Get quantile", 0, 0, 0.5, "Hertz")
        if not f0 or not np.isfinite(f0):
            return a
        out = call(snd, "Change gender", 60, 600, fr, f0 * 2 ** (st / 12), 1.0, 1.0)
        y = np.asarray(out.values[0], dtype=np.float32)
        peak = float(np.abs(y).max() or 1.0)
        return y * min(1.0, 0.95 / peak) if peak > 0.95 else y
    except Exception as e:
        log(f"Không tạo được biến thể giọng '{variant}': {e}")
        return a


def label(base: str, variant: str) -> str:
    return base if not variant else f"{base} ({variant})"


def _pools(s: dict, tts_mode: str, genre: str, available: dict) -> dict:
    if tts_mode == "nano":
        pools = s["nano_voices"]
    else:
        gv = s["genre_voices"]
        pools = gv.get(genre) or gv["default"]
    out = {}
    for g in ("male", "female"):
        lst = [v for v in pools.get(g, []) if v in available] or [v for v, gg in available.items() if gg == g]
        lead = (s.get(f"lead_{g}_voice") or "").strip()
        if lead and lead in available:
            lst = [lead] + [v for v in lst if v != lead]
        out[g] = lst
    return out


def cast(job: Job, tts_mode: str, available: dict) -> dict:
    tr = job.read("transcript.json")
    tl = job.read("translation.json")
    s = job.settings
    pools = _pools(s, tts_mode, tl.get("genre", "khac"), available)
    use_var = bool(s.get("voice_variants", True))
    llm_spk = tl.get("speakers", {}) or {}
    order = sorted(tr["speakers"].items(), key=lambda kv: kv[1]["talk_time"], reverse=True)
    used: set = set()
    base_used: Counter = Counter()
    leads: dict = {}      # giọng gốc của vai chính mỗi giới
    casting = {}
    by_name = {}   # AI dịch nhận ra nhiều mã người nói là cùng 1 nhân vật -> dùng chung giọng
    for spk, info in order:
        li = llm_spk.get(spk) or {}
        nm = (li.get("name_vi") or "").strip().lower()
        if nm and nm in by_name:
            casting[spk] = dict(by_name[nm])
            continue
        g = li.get("gender")
        if g not in ("male", "female"):
            g = info.get("gender_voice")
        if g not in ("male", "female"):
            g = "male"
        age = li.get("age") if li.get("age") in AGE_PREF else "adult"
        voice_g = "female" if age == "child" else g     # giọng trẻ con: lồng bằng giọng nữ, nâng cao độ
        pool = pools[voice_g] or pools["male"] or pools["female"]
        prefs = AGE_PREF[age] if use_var else [""]
        allv = prefs + ([v for v in VARIANTS if v not in prefs and v != "bé"] if use_var else [])
        cands = [(b, v) for v in allv for b in pool if (b, v) not in used]
        if cands:
            # điểm thấp = tốt: giọng gốc ít người dùng nhất (giọng của vai chính để dành cho vai chính),
            # rồi tới biến thể hợp tuổi, rồi thứ tự ưu tiên theo thể loại
            pick = min(cands, key=lambda c: (base_used[c[0]] + (1 if c[0] in leads.values() else 0),
                                             allv.index(c[1]), pool.index(c[0])))
        else:
            pick = (pool[len(casting) % len(pool)], prefs[0])
        if voice_g not in leads:
            leads[voice_g] = pick[0]
        used.add(pick)
        base_used[pick[0]] += 1
        casting[spk] = {"voice": label(*pick), "base": pick[0], "variant": pick[1], "gender": g, "age": age,
                        "name": li.get("name_vi", "")}
        if nm:
            by_name[nm] = casting[spk]
    return casting


def atempo(src, dst, speed: float) -> None:
    ffmpeg(["-i", src, "-filter:a", f"atempo={speed:.4f}", dst])


def run(job: Job) -> None:
    from . import translate as tmod

    t0 = time.time()
    s = job.settings
    mode = s.get("tts_mode", "turbo")
    tr = job.read("transcript.json")
    tl = job.read("translation.json")
    lines = tr["lines"]
    vi = {l["id"]: l["vi"] for l in tl["lines"]}
    dur_total = tr["duration"]
    max_speed = float(s.get("max_speed", 1.2))
    hard_max = float(s.get("hard_max_speed", 1.45))
    borrow = float(s.get("borrow_gap_s", 1.5))
    default_rate = float(s.get("speech_rate_sps", 4.8))

    job.progress(0.02, "nạp model giọng đọc")
    from ..ttsload import load as load_tts
    tts = load_tts(mode, threads(), s.get("tts_precision", "fp32"))
    sr = int(tts.sample_rate)
    presets = getattr(tts, "_preset_voices", {}) or {}
    available = {name: (v.get("gender") or "") for name, v in presets.items()}
    if not available:
        available = {vid: "" for _, vid in tts.list_preset_voices()}
    casting = cast(job, mode, available)
    log("Phân vai: " + ", ".join(f"{k}->{v['voice']} ({v['gender']}, {v['age']})" for k, v in casting.items()))
    log(f"Nạp model xong sau {time.time() - t0:.1f}s")

    out_dir = job.p("tts")
    out_dir.mkdir(exist_ok=True)
    todo = [l for l in lines if vi.get(l["id"])]
    idx = {l["id"]: i for i, l in enumerate(lines)}
    known_rates = read_json(RATES_FILE, {}) or {}

    def cinfo(ln):
        return casting.get(ln["spk"]) or {"voice": "", "base": None, "variant": ""}

    def synth(ln, text):
        c = cinfo(ln)
        a = tts.infer(normalize_vi(text), voice=c["base"])
        a = trim_silence(np.asarray(a, dtype=np.float32), sr)
        a = apply_variant(a, sr, c["variant"])
        save_audio(out_dir / f"{ln['id']:04d}.wav", a, sr)
        return len(a) / sr

    def window(i):
        ln = lines[i]
        nxt = lines[i + 1]["start"] if i + 1 < len(lines) else dur_total
        return max(0.5, min(nxt - ln["start"] - 0.08, (ln["end"] - ln["start"]) + borrow))

    def rate_for(c, measured):
        return (measured.get(c["voice"]) or known_rates.get(c["voice"]) or known_rates.get(c["base"] or "")
                or default_rate)

    shortened = 0

    def do_shorten(cands, note):
        nonlocal shortened
        if not cands:
            return []
        log(f"{len(cands)} câu quá dài -> rút gọn ({note})")
        try:
            new = tmod.shorten(job, cands)
        except Exception as e:
            log(f"Rút gọn lỗi ({e}) - dùng tăng tốc thay thế")
            return []
        changed = []
        for it in cands:
            nv = new.get(it["id"])
            if nv and vi_syllables(nv) < vi_syllables(it["vi"]):
                vi[it["id"]] = nv
                changed.append(it["id"])
                shortened += 1
        return changed

    # 1) rút gọn TRƯỚC khi đọc những câu chắc chắn quá dài (ước lượng bằng tốc độ đọc đã đo)
    pre = []
    for ln in todo:
        w = window(idx[ln["id"]])
        rate = rate_for(cinfo(ln), {})
        est = vi_syllables(vi[ln["id"]]) / rate
        if est / w > max_speed * 1.15:
            pre.append({"id": ln["id"], "vi": vi[ln["id"]], "max_syll": max(2, int(w * max_speed * rate * 0.95))})
    if pre:
        job.progress(0.04, "rút gọn câu dài")
        do_shorten(pre, "trước khi đọc")

    # 2) đọc tất cả
    raw = {}
    t_tts = time.time()
    for k, ln in enumerate(todo):
        raw[ln["id"]] = synth(ln, vi[ln["id"]])
        job.progress(0.05 + 0.7 * (k + 1) / max(1, len(todo)), f"đọc câu {k + 1}/{len(todo)}")
    speech_sec = sum(raw.values())
    log(f"Đọc {len(todo)} câu, {speech_sec:.1f}s giọng trong {time.time() - t_tts:.1f}s "
        f"(RTF {((time.time() - t_tts) / max(speech_sec, 0.1)):.2f})")

    # tốc độ đọc thực tế từng giọng (âm tiết/giây)
    rates = {}
    for ln in todo:
        d = raw[ln["id"]]
        if d > 0.8:
            rates.setdefault(cinfo(ln)["voice"], []).append(vi_syllables(vi[ln["id"]]) / d)
    rate_of = {v: float(np.median(r)) for v, r in rates.items()}

    # 3) câu vẫn quá dài -> nhờ AI rút gọn rồi đọc lại
    long_ones = []
    for ln in todo:
        w = window(idx[ln["id"]])
        if raw[ln["id"]] / w > max_speed:
            rate = rate_for(cinfo(ln), rate_of)
            long_ones.append({"id": ln["id"], "vi": vi[ln["id"]], "max_syll": max(2, int(w * max_speed * rate * 0.95))})
    if long_ones:
        job.progress(0.78, "rút gọn câu dài")
        for lid in do_shorten(long_ones, "sau khi đọc"):
            raw[lid] = synth(lines[idx[lid]], vi[lid])

    # 4) khớp tốc độ
    fit = []
    job.progress(0.92, "khớp thời gian")
    for ln in todo:
        i = idx[ln["id"]]
        w = window(i)
        d = raw[ln["id"]]
        speed = 1.0
        f = out_dir / f"{ln['id']:04d}.wav"
        if d > w:
            speed = min(d / w, hard_max)
            sp = out_dir / f"{ln['id']:04d}_fit.wav"
            atempo(f, sp, speed)
            f = sp
        final = d / speed
        fit.append({"id": ln["id"], "spk": ln["spk"], "voice": cinfo(ln)["voice"],
                    "start": ln["start"], "orig_end": ln["end"], "window": round(w, 3),
                    "dur_raw": round(d, 3), "speed": round(speed, 3), "dur": round(final, 3),
                    "overflow": round(max(0.0, final - w), 3), "file": f.name, "vi": vi[ln["id"]]})

    # lưu tốc độ đọc trung bình để lần sau dịch ước lượng độ dài chính xác hơn
    try:
        allr = read_json(RATES_FILE, {}) or {}
        for v, r in rate_of.items():
            old = allr.get(v)
            allr[v] = round(r if old is None else 0.7 * old + 0.3 * r, 3)
        write_json(RATES_FILE, allr)
    except Exception:
        pass

    job.write("fit.json", {"sr": sr, "mode": mode, "casting": casting, "lines": fit, "rates": rate_of,
                           "shortened": shortened, "pre_shortened": len(pre), "seconds": round(time.time() - t0, 1),
                           "speech_seconds": round(speech_sec, 1)})
    sped = sum(1 for f in fit if f["speed"] > 1.0)
    log(f"TTS xong {time.time() - t0:.1f}s: {len(fit)} câu, rút gọn {shortened}, tăng tốc {sped}")
