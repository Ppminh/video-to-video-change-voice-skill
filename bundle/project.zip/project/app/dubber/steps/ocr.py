"""B4. Dò phụ đề chữ Trung in cứng trên hình (bản tối ưu, nhanh hơn ~5-10 lần).

Cách hoạt động (2 lượt):
1. Lượt dò (nhanh): chỉ chụp ~40 khung hình đúng lúc đang có người nói (lấy từ bước nghe ở B3),
   đọc chữ cả khung -> tìm ra "vùng phụ đề" (vị trí có chữ Hán lặp lại nhiều nhất).
   Không thấy phụ đề -> bỏ qua lượt 2 luôn (video không có hardsub).
2. Lượt đọc: chỉ cắt dải hình chứa phụ đề (nhỏ hơn cả khung ~8 lần) 2 lần/giây.
   Khung nào gần giống khung vừa đọc (chữ chưa đổi) -> dùng lại kết quả, không đọc lại.
Mẹo tăng tốc khác: RapidOCR mặc định phóng to ảnh nhỏ lên 736px trước khi dò chữ (rất chậm);
ở đây đặt giới hạn theo cạnh dài nên ảnh nhỏ được giữ nguyên kích thước.
Kết quả dùng cho: làm mờ vùng đó, đặt phụ đề Việt, và giúp AI dịch sửa lỗi nghe nhầm.
"""
from __future__ import annotations

import subprocess
import time
from collections import Counter

import numpy as np

from .. import paths
from ..utils import Job, cjk_count, ffmpeg_bin, ffprobe_bin, log, threads

PROBES = 40          # số khung hình tối đa ở lượt dò
MIN_PROBES = 24      # ít keyframe quá thì chụp thêm cho đủ
DIFF_SAME = 3.0      # chênh lệch điểm ảnh trung bình (0-255) dưới mức này = chữ chưa đổi


def _hw() -> list:
    return ["-hwaccel", "videotoolbox"] if paths.IS_MAC else []


def _engine(side: int):
    from rapidocr_onnxruntime import RapidOCR
    try:
        return RapidOCR(det_limit_side_len=side, det_limit_type="max", intra_op_num_threads=threads())
    except Exception:
        return RapidOCR()


def _grab(src, t: float, w: int, h: int):
    """Chụp 1 khung hình tại giây t (tua nhanh tới khung khóa gần nhất rồi giải mã vài khung)."""
    cmd = [ffmpeg_bin(), "-hide_banner", "-loglevel", "error", *_hw(), "-ss", f"{t:.3f}", "-i", str(src),
           "-frames:v", "1", "-vf", f"scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    out = subprocess.run(cmd, capture_output=True).stdout
    if len(out) < w * h * 3:
        return None
    return np.frombuffer(out[:w * h * 3], np.uint8).reshape(h, w, 3)


def _frames(src, vf: str, fps: float, w: int, h: int, pre=(), post=()):
    cmd = [ffmpeg_bin(), "-hide_banner", "-loglevel", "error", *_hw(), *pre, "-i", str(src),
           *post, "-vf", vf, "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    size = w * h * 3
    i = 0
    try:
        while True:
            buf = p.stdout.read(size)
            if len(buf) < size:
                break
            yield i / fps, np.frombuffer(buf, np.uint8).reshape(h, w, 3)
            i += 1
    finally:
        p.stdout.close()
        p.wait()


def _detect(engine, img, oy: float = 0.0, sy: float = 1.0):
    """Đọc chữ, trả về [(x1, y1, x2, y2, chữ)] theo tọa độ 0..1 của KHUNG GỐC."""
    h, w = img.shape[:2]
    res, _ = engine(img, use_cls=False)
    out = []
    for box, text, score in res or []:
        if cjk_count(text) < 2 or float(score) < 0.6:
            continue
        xs = [p[0] for p in box]
        ys = [p[1] for p in box]
        x1, x2 = min(xs) / w, max(xs) / w
        y1, y2 = oy + sy * min(ys) / h, oy + sy * max(ys) / h
        if not (0.012 < (y2 - y1) < 0.12) or (x2 - x1) < 0.05:
            continue
        out.append((x1, y1, x2, y2, text))
    return out


def _merge(times, gap):
    out = []
    for t in sorted(times):
        if out and t - out[-1][1] <= gap:
            out[-1][1] = t
        else:
            out.append([t, t])
    return out


def _keyframes(src, w: int, h: int, max_n: int):
    """Khung khóa (keyframe) giải mã cực nhanh vì không cần giải mã các khung ở giữa."""
    r = subprocess.run([ffprobe_bin(), "-v", "error", "-select_streams", "v:0", "-show_entries",
                        "packet=pts_time,flags", "-of", "csv=p=0", str(src)], capture_output=True, text=True)
    times = []
    for line in r.stdout.splitlines():
        parts = line.strip().split(",")
        if len(parts) >= 2 and "K" in parts[1]:
            try:
                times.append(float(parts[0]))
            except ValueError:
                pass
    times.sort()
    vf = f"scale={w}:{h}"
    cmd_extra = ["-skip_frame", "nokey"]
    frames = []
    for i, (_, img) in enumerate(_frames(src, vf, 1.0, w, h, pre=cmd_extra, post=["-fps_mode", "passthrough"])):
        frames.append(img)
    if not frames:
        return []
    if len(times) != len(frames):
        times = list(np.linspace(0, max(times or [0]), len(frames)))
    pairs = list(zip(times, frames))
    if len(pairs) > max_n:
        idx = np.linspace(0, len(pairs) - 1, max_n).round().astype(int)
        pairs = [pairs[i] for i in idx]
    return pairs


def _probe_times(job: Job, dur: float, have: list[float], need: int) -> list[float]:
    """Bổ sung thời điểm dò: giữa các câu thoại (lúc phụ đề chắc chắn đang hiện), tránh trùng keyframe."""
    tr = job.read("transcript.json", {}) or {}
    mids = [(l["start"] + l["end"]) / 2 for l in tr.get("lines", [])]
    mids = [t for t in mids if 0 <= t < dur - 0.1 and all(abs(t - k) > 1.0 for k in have)]
    if not mids:
        mids = [t for t in np.linspace(dur * 0.05, dur * 0.95, need) if all(abs(t - k) > 1.0 for k in have)]
    if len(mids) > need:
        idx = np.linspace(0, len(mids) - 1, need).round().astype(int)
        mids = [mids[i] for i in idx]
    return [round(float(t), 2) for t in mids]


def _band_from(dets, n_frames: int, min_frames: int):
    """dets: [(t, x1, y1, x2, y2, chữ)] -> (vùng phụ đề, các ô thuộc vùng) hoặc (None, [])."""
    if not dets:
        return None, []
    cnt = Counter(d[5] for d in dets)
    static = {txt for txt, c in cnt.items() if c >= 0.5 * n_frames and n_frames >= 8}
    subs = [d for d in dets if d[5] not in static]
    if not subs:
        return None, []
    centers = np.array([(d[2] + d[4]) / 2 for d in subs])
    hist, edges = np.histogram(centers, bins=50, range=(0, 1))
    k = int(np.argmax(hist))
    mode = (edges[k] + edges[k + 1]) / 2
    band_dets = [d for d, c in zip(subs, centers) if abs(c - mode) <= 0.07]
    if len({d[0] for d in band_dets}) < min_frames:
        return None, []
    y1 = float(np.percentile([d[2] for d in band_dets], 5)) - 0.012
    y2 = float(np.percentile([d[4] for d in band_dets], 95)) + 0.012
    x1 = float(np.percentile([d[1] for d in band_dets], 3)) - 0.03
    x2 = float(np.percentile([d[3] for d in band_dets], 97)) + 0.03
    return [max(0.0, x1), max(0.0, y1), min(1.0, x2), min(1.0, y2)], band_dets


def run(job: Job) -> None:
    t0 = time.time()
    meta = job.read("meta.json")
    W, H = int(meta["width"]), int(meta["height"])
    dur = float(meta.get("duration", 1))
    src = job.p("source.mp4")
    fps = float(job.settings.get("ocr_fps", 2.0))
    result = {"band": None, "intervals": [], "captions": [], "frames": 0, "probe_frames": 0}

    # ---------- Lượt 1: dò vùng phụ đề trên ~40 khung (keyframe + giữa các câu thoại)
    w = 480 if W >= H else 360
    h = int(round(H * w / W / 2)) * 2
    eng = _engine(max(w, h))
    pairs = _keyframes(src, w, h, PROBES)
    extra = []
    if len(pairs) < MIN_PROBES:
        extra = _probe_times(job, dur, [t for t, _ in pairs], MIN_PROBES - len(pairs))
    times = [t for t, _ in pairs] + extra
    probe = []
    total_p = max(1, len(times))
    for k, (t, img) in enumerate(pairs):
        probe += [(t, *d) for d in _detect(eng, img)]
        if k % 5 == 0:
            job.progress(0.3 * (k + 1) / total_p, f"dò vùng phụ đề {k + 1}/{total_p}")
    for k, t in enumerate(extra):
        img = _grab(src, t, w, h)
        if img is not None:
            probe += [(t, *d) for d in _detect(eng, img)]
        job.progress(0.3 * (len(pairs) + k + 1) / total_p, f"dò vùng phụ đề {len(pairs) + k + 1}/{total_p}")
    result["probe_frames"] = len(times)
    band0, _ = _band_from(probe, len(times), min_frames=3)
    t1 = time.time() - t0
    if not band0:
        job.write("ocr.json", result)
        log(f"OCR: không thấy phụ đề cứng ({len(times)} khung dò, {t1:.1f}s) -> bỏ qua lượt đọc")
        return

    # ---------- Lượt 2: chỉ đọc dải phụ đề, bỏ qua khung không đổi
    cy1 = max(0.0, band0[1] - 0.05)
    cy2 = min(1.0, band0[3] + 0.05)
    Y1 = int(cy1 * H) // 2 * 2
    CH = max(16, int((cy2 - cy1) * H) // 2 * 2)
    cw = 640 if W >= H else 480
    ch = max(16, int(round(CH * cw / W / 2)) * 2)
    oy, sy = Y1 / H, CH / H
    eng = _engine(cw)
    vf = f"fps={fps},crop={W}:{CH}:0:{Y1},scale={cw}:{ch}"
    dets = []
    n = skipped = 0
    last_gray, last_res = None, []
    total = max(1, int(dur * fps))
    for t, img in _frames(src, vf, fps, cw, ch):
        n += 1
        gray = img.mean(axis=2, dtype=np.float32)
        if last_gray is not None and float(np.abs(gray - last_gray).mean()) < DIFF_SAME:
            res = last_res
            skipped += 1
        else:
            res = _detect(eng, img, oy, sy)
            last_gray, last_res = gray, res
        dets += [(t, *d) for d in res]
        if n % 20 == 0:
            job.progress(0.3 + 0.65 * min(1.0, n / total), f"đọc phụ đề {n}/{total} khung")

    result["frames"] = n
    band, band_dets = _band_from(dets, n, min_frames=4)
    if band:
        frames_with = {d[0] for d in band_dets}
        result["band"] = band
        iv = _merge(frames_with, gap=1.6 / fps)
        result["intervals"] = [[round(max(0, a - 0.35), 2), round(b + 0.35 + 1 / fps, 2)] for a, b in iv]
        by_t = {}
        for d in sorted(band_dets, key=lambda d: (d[0], d[2], d[1])):
            by_t.setdefault(d[0], []).append(d[5])
        caps = []
        for t in sorted(by_t):
            txt = " ".join(by_t[t])
            if caps and caps[-1]["text"] == txt and t - caps[-1]["end"] <= 1.6 / fps:
                caps[-1]["end"] = round(t, 2)
            else:
                caps.append({"start": round(t, 2), "end": round(t, 2), "text": txt})
        result["captions"] = caps
    job.write("ocr.json", result)
    log(f"OCR: dò {len(times)} khung ({t1:.1f}s) + đọc {n} khung (bỏ qua {skipped} khung không đổi), "
        f"vùng phụ đề={result['band']}, {len(result['captions'])} câu chữ, tổng {time.time() - t0:.1f}s")
