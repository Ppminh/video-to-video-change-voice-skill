"""B8. Trộn giọng Việt với nhạc nền gốc.

- Nền = file nhạc + tiếng động đã tách ở B2.
- Giữ lại tiếng cười/khóc/la hét gốc: những đoạn có âm trong file 'giọng' mà không phải lời thoại.
- Ducking: hạ nhạc nền vài dB khi đang có lời để nghe rõ giọng.
- Chuẩn hóa độ to về -14 LUFS (mức các nền tảng video thường dùng).
Tối ưu: đường bao âm lượng tính trên khung 10ms (100 điểm/giây) thay vì từng mẫu âm thanh
(44.100 điểm/giây) -> nhanh hơn hàng trăm lần, kết quả nghe như nhau.
"""
from __future__ import annotations

import numpy as np

from ..utils import Job, load_audio, log, save_audio

SR = 44100


def _place(track, clip, start_s):
    a = int(round(start_s * SR))
    if a >= len(track):
        return
    b = min(len(track), a + len(clip))
    track[a:b] += clip[:b - a]


def _fade(x, n):
    n = min(n, len(x) // 2)
    if n > 1:
        r = np.linspace(0, 1, n, dtype=np.float32)
        x[:n] *= r
        x[-n:] *= r[::-1]
    return x


HOP = SR // 100   # 10ms


def _frames_mean(x: np.ndarray) -> np.ndarray:
    nf = int(np.ceil(len(x) / HOP))
    return np.pad(x, (0, nf * HOP - len(x))).reshape(nf, HOP).mean(axis=1)


def _smooth(f: np.ndarray, frames: int) -> np.ndarray:
    frames = max(1, int(frames))
    return np.convolve(f, np.ones(frames) / frames, mode="same")


def _to_samples(f: np.ndarray, n: int) -> np.ndarray:
    """Nội suy tuyến tính từ 100 điểm/giây về từng mẫu âm thanh."""
    g = np.append(f, f[-1]).astype(np.float32)
    ramp = np.arange(HOP, dtype=np.float32) / HOP
    out = (g[:-1, None] + (g[1:] - g[:-1])[:, None] * ramp[None, :]).reshape(-1)
    return out[:n] if len(out) >= n else np.pad(out, (0, n - len(out)), mode="edge")


def run(job: Job) -> None:
    import pyloudnorm as pyln

    s = job.settings
    tr = job.read("transcript.json")
    fit = job.read("fit.json")
    bg, sr_bg = load_audio(job.p("background.wav"), sr=SR)
    voc, _ = load_audio(job.p("vocals.wav"), sr=SR)
    meta = job.read("meta.json")
    n = int(round(float(meta.get("duration", tr["duration"])) * SR))
    if bg.ndim == 1:
        bg = bg[:, None]
    bg = np.pad(bg, ((0, max(0, n - len(bg))), (0, 0)))[:n]
    if bg.shape[1] == 1:
        bg = np.repeat(bg, 2, axis=1)
    voc = np.pad(voc, ((0, max(0, n - len(voc))), (0, 0)))[:n]
    if voc.shape[1] == 1:
        voc = np.repeat(voc, 2, axis=1)

    voice = np.zeros(n, dtype=np.float32)
    for f in fit["lines"]:
        clip, _ = load_audio(job.p("tts") / f["file"], sr=SR, mono=True)
        maxlen = int((f["window"] + 0.3) * SR)
        if len(clip) > maxlen:   # quá dài -> cắt và làm mờ đuôi
            clip = clip[:maxlen]
        _place(voice, _fade(clip.copy(), int(0.008 * SR)), f["start"])

    # giữ âm thanh không lời (cười, khóc...) từ giọng gốc
    nf = int(np.ceil(n / HOP))
    keep = np.zeros(nf, dtype=np.float32)
    for seg in tr.get("nonspeech", []):
        keep[int(seg["start"] * 100):int(seg["end"] * 100)] = 1.0
    if keep.any():
        k = _to_samples(_smooth(keep, 5), n)
        bg = bg + voc * k[:, None] * 0.9
    del voc

    # ducking: đường bao giọng Việt -> giảm nền
    env = _smooth(_frames_mean(np.abs(voice)), 25)
    active = _smooth((env > 0.01).astype(np.float32), 20)
    duck = 10 ** (float(s.get("duck_db", -5.0)) / 20)
    gain = _to_samples((1.0 - (1.0 - duck) * np.clip(active, 0, 1)).astype(np.float32), n)
    mix = bg * gain[:, None] + voice[:, None]
    del bg

    # chuẩn hóa độ to
    meter = pyln.Meter(SR)
    try:
        loud = meter.integrated_loudness(mix)
        if np.isfinite(loud):
            mix = pyln.normalize.loudness(mix, loud, float(s.get("target_lufs", -14.0)))
    except Exception as e:
        log(f"Bỏ qua chuẩn hóa độ to: {e}")
    # chống vỡ tiếng: nén mềm phần vượt 0.9
    over = np.abs(mix) > 0.9
    if over.any():
        mix[over] = np.sign(mix[over]) * (0.9 + 0.1 * np.tanh((np.abs(mix[over]) - 0.9) / 0.1))
    save_audio(job.p("mix.wav"), mix.astype(np.float32), SR)
    log(f"Trộn xong: {n / SR:.1f}s, giữ {len(tr.get('nonspeech', []))} đoạn âm không lời")
